import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class TodoView extends StatefulWidget {
  const TodoView({super.key});

  @override
  State<TodoView> createState() => _TodoViewState();
}

class _TodoViewState extends State<TodoView> {
  TextEditingController todoController =  TextEditingController();
  List todoView = [];
  addTodo(){
    todoView.add(todoController.text);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple[300],
        title: const TextField(
          obscureText: false,
          decoration: InputDecoration(
            border: OutlineInputBorder(
            ),
            labelText: 'Todo.....'
          ),
        ),
        actions: [
          IconButton(onPressed:(){
            addTodo();
            setState(() {});
          }, icon: const Icon(Icons.check))
        ],
      ),
      body: ListView.builder(itemCount: todoView.length, itemBuilder: (context, index){
        return ListTile(
          tileColor: Colors.white,
          title: Text("${todoView[index]}"),
        );
      }),
    );
  }
}
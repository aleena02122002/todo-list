import 'package:flutter/material.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {

  int count = 0;
  addValue(){
    count++;
    print(count);
  }

  subValue(){
    --count;
    print(count);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
      ),
      body: Column(
        children: [
          Center(
            child: Text("$count",
            style: const TextStyle(fontSize: 40),),
          ),
          FloatingActionButton(child: Icon(Icons.remove), onPressed: (){
            subValue();
            setState(() {});
          })
        ],
      ),
      floatingActionButton: FloatingActionButton(backgroundColor: Colors.amber[100],child: Icon(Icons.add), onPressed: (){
        addValue();
        setState(() {});
      }),
    );
  }
}